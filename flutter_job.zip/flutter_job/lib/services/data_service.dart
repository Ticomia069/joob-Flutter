import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:habit_tracker/screens/home_screen.dart';
// ADICIONADO: Importações necessárias para o sqflite funcionar nos testes de desktop.
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

void main() {
  // ADICIONADO: Configuração para inicializar o banco de dados no ambiente de teste.
  // Isto deve ser chamado antes de qualquer teste que use o banco de dados.
  setUpAll(() {
    // Inicializa o FFI (Foreign Function Interface) do sqflite.
    sqfliteFfiInit();
    // Muda a fábrica de banco de dados padrão para a versão FFI.
    databaseFactory = databaseFactoryFfi;
  });

  testWidgets(
      'HomeScreen exibe a mensagem inicial e navega para adicionar hábito',
      (WidgetTester tester) async {
    // Arrange: Constrói a tela principal dentro de um MaterialApp para dar o contexto necessário.
    await tester.pumpWidget(const MaterialApp(
      home: HomeScreen(),
    ));

    // Espera o FutureBuilder inicial do banco de dados resolver.
    await tester.pumpAndSettle();

    // Assert: Verifica se a mensagem para lista vazia (para o dia atual) é exibida.
    // Corrigido: O texto agora corresponde exatamente ao do widget.
    expect(
        find.text('Nenhum hábito para este dia.\nClique no + para adicionar.'),
        findsOneWidget);

    // Act: Simula o toque no botão de adicionar.
    await tester.tap(find.byIcon(Icons.add));

    // Espera a animação de transição da tela terminar.
    await tester.pumpAndSettle();

    // Assert: Verifica se a tela de adicionar hábito foi aberta (procurando pelo título dela).
    expect(find.text('Adicionar Novo Hábito'), findsOneWidget);
  });
}
