import 'package:sqflite/sqflite.dart';
import '../models/habit.dart';
import '../services/database_service.dart'; // Apenas a importação correta é necessária

class HabitRepository {
  final Database db;

  HabitRepository({required this.db});

  Future<int> insertHabit(Habit habit) async {
    return await db.insert(DatabaseService.tableHabits, habit.toMap());
  }

  Future<List<Habit>> getHabitsForDate(DateTime date) async {
    String dateString = date.toIso8601String().substring(0, 10);
    final List<Map<String, dynamic>> maps = await db.query(
      DatabaseService.tableHabits,
      where: "SUBSTR(${DatabaseService.columnCreatedDate}, 1, 10) = ?",
      whereArgs: [dateString],
    );
    return List.generate(maps.length, (i) => Habit.fromMap(maps[i]));
  }

  /// NOVO MÉTODO: Busca todos os hábitos registados no banco de dados.
  /// Essencial para calcular estatísticas gerais.
  Future<List<Habit>> getAllHabits() async {
    final List<Map<String, dynamic>> maps = await db.query(
      DatabaseService.tableHabits,
      orderBy: '${DatabaseService.columnCreatedDate} DESC',
    );
    return List.generate(maps.length, (i) => Habit.fromMap(maps[i]));
  }

  Future<int> updateHabit(Habit habit) async {
    return await db.update(
      DatabaseService.tableHabits,
      habit.toMap(),
      where: '${DatabaseService.columnId} = ?',
      whereArgs: [habit.id],
    );
  }

  Future<int> deleteHabit(int id) async {
    return await db.delete(
      DatabaseService.tableHabits,
      where: '${DatabaseService.columnId} = ?',
      whereArgs: [id],
    );
  }
}
