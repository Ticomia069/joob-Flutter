import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

/// Uma classe de serviço singleton que gere a conexão com o banco de dados SQLite.
/// Isto garante que apenas uma conexão com o banco de dados seja aberta durante o ciclo de vida da aplicação.
class DatabaseService {
  // --- Constantes da Tabela de Hábitos ---
  // Definir nomes de tabela e colunas como constantes previne erros de digitação
  // e permite que sejam reutilizados de forma segura noutras partes da aplicação (como no repositório).
  static const String tableHabits = 'habits';
  static const String columnId = 'id';
  static const String columnName = 'name';
  static const String columnCreatedDate = 'createdDate';
  static const String columnIsCompleted = 'isCompleted';

  // --- Padrão Singleton ---
  // O construtor privado impede a criação de instâncias diretas da classe.
  DatabaseService._privateConstructor();
  // A única instância estática e final desta classe.
  static final DatabaseService instance = DatabaseService._privateConstructor();

  // Uma referência estática e privada ao banco de dados para evitar reaberturas.
  static Database? _database;

  /// Getter público para a instância do banco de dados.
  /// Se o banco de dados já estiver inicializado, retorna-o.
  /// Caso contrário, inicializa-o primeiro e depois retorna-o.
  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDatabase();
    return _database!;
  }

  /// Inicializa o banco de dados.
  /// Encontra o caminho apropriado no sistema de ficheiros do dispositivo e abre a conexão.
  Future<Database> _initDatabase() async {
    // Usando getDatabasesPath() do sqflite para encontrar um local padrão.
    String databasesPath = await getDatabasesPath();
    String path = join(databasesPath, "HabitTracker.db");

    return await openDatabase(
      path,
      version: 1,
      onCreate:
          _onCreate, // Método a ser executado na primeira vez que o banco é criado.
    );
  }

  /// Chamado quando o banco de dados é criado pela primeira vez.
  /// Aqui, definimos o esquema inicial, criando as tabelas necessárias.
  Future<void> _onCreate(Database db, int version) async {
    await db.execute('''
      CREATE TABLE $tableHabits (
        $columnId INTEGER PRIMARY KEY AUTOINCREMENT,
        $columnName TEXT NOT NULL,
        $columnCreatedDate TEXT NOT NULL,
        $columnIsCompleted INTEGER NOT NULL DEFAULT 0
      )
    ''');
    // Se no futuro precisar de mais tabelas, os comandos `CREATE TABLE` para elas
    // seriam adicionados aqui.
  }
}
