import 'package:flutter/material.dart';
import 'package:habit_tracker/services/habit_repository.dart';
import 'package:habit_tracker/services/database_service.dart';
import 'package:intl/intl.dart';
import '../models/habit.dart';
import "package:habit_tracker/widgets/screens/components/add_habit_screen.dart";
import "package:habit_tracker/widgets/screens/components/habit_title.dart";

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  late final HabitRepository _habitRepository;
  late final Future<void> _initFuture;
  late Future<List<Habit>> _habitsFuture;
  DateTime _selectedDate = DateTime.now();

  @override
  void initState() {
    super.initState();
    _initFuture = _initializeDependencies();
  }

  Future<void> _initializeDependencies() async {
    final database = await DatabaseService.instance.database;
    _habitRepository = HabitRepository(db: database);
    _habitsFuture = _habitRepository.getHabitsForDate(_selectedDate);
  }

  void _refreshHabitList() {
    setState(() {
      _habitsFuture = _habitRepository.getHabitsForDate(_selectedDate);
    });
  }

  Future<void> _selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: _selectedDate,
      firstDate: DateTime(2020),
      lastDate: DateTime(2030),
      locale: const Locale('pt', 'BR'),
    );
    if (picked != null && picked != _selectedDate) {
      setState(() {
        _selectedDate = picked;
      });
      _refreshHabitList();
    }
  }

  void _navigateToAddHabit() async {
    await Navigator.push(
      context,
      MaterialPageRoute(
          builder: (context) =>
              AddHabitScreen(habitRepository: _habitRepository)),
    );
    _refreshHabitList();
  }

  void _toggleHabitStatus(Habit habit, bool? isCompleted) async {
    habit.isCompleted = isCompleted ?? false;
    await _habitRepository.updateHabit(habit);
    _refreshHabitList();
  }

  void _deleteHabit(int id) async {
    await _habitRepository.deleteHabit(id);
    _refreshHabitList();
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
            content: Text('Hábito excluído.'), backgroundColor: Colors.red),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Meus Hábitos'),
        actions: [
          IconButton(
            icon: const Icon(Icons.calendar_today),
            onPressed: () => _selectDate(context),
          ),
          IconButton(
            icon: const Icon(Icons.bar_chart),
            onPressed: () => Navigator.pushNamed(context, '/stats'),
          ),
        ],
      ),
      body: FutureBuilder<void>(
        future: _initFuture,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snapshot.hasError) {
            return Center(
                child: Text("Erro fatal ao inicializar: ${snapshot.error}"));
          }

          return Column(
            children: [
              _buildDateHeader(),
              Expanded(
                child: _buildHabitsList(),
              ),
            ],
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _navigateToAddHabit,
        tooltip: 'Adicionar Hábito',
        child: const Icon(Icons.add),
      ),
    );
  }

  Widget _buildHabitsList() {
    return FutureBuilder<List<Habit>>(
      future: _habitsFuture,
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator());
        }
        if (snapshot.hasError) {
          return Center(
              child: Text('Erro ao carregar hábitos: ${snapshot.error}'));
        }
        if (!snapshot.hasData || snapshot.data!.isEmpty) {
          return const Center(
            child: Text(
              'Nenhum hábito para este dia.\nClique no + para adicionar.',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 18, color: Colors.grey),
            ),
          );
        }

        final habits = snapshot.data!;
        return ListView.builder(
          itemCount: habits.length,
          itemBuilder: (context, index) {
            final habit = habits[index];
            return HabitTile(
              habit: habit,
              onChanged: (isCompleted) =>
                  _toggleHabitStatus(habit, isCompleted),
              onDelete: () => _deleteHabit(habit.id!),
            );
          },
        );
      },
    );
  }

  Widget _buildDateHeader() {
    return Container(
      padding: const EdgeInsets.all(16.0),
      color: Theme.of(context).colorScheme.primary.withAlpha(26),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            DateFormat.yMMMMd('pt_BR').format(_selectedDate),
            style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: Theme.of(context).colorScheme.primary),
          ),
        ],
      ),
    );
  }
}
