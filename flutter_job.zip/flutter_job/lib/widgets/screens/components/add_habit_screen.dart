import 'package:flutter/material.dart';
import 'package:habit_tracker/services/habit_repository.dart';

class AddHabitScreen extends StatelessWidget {
  const AddHabitScreen({super.key, required HabitRepository habitRepository});

  @override
  // 1. O parâmetro 'context' precisa de um nome.
  Widget build(BuildContext context) {
    // 2. 'appBar' e 'body' devem estar dentro dos parênteses de Scaffold().
    return Scaffold(
      appBar: AppBar(
        title: const Text("Adicionar Novo Hábito"),
      ),
      body: const Center(
        child: Text("Adicione seu formulário de hábito aqui!"),
      ),
    ); // 3. Ponto e vírgula no final do return.
  }
}
