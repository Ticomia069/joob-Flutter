import 'package:flutter/material.dart';
// 1. Adicionado o pacote de internacionalização para formatar datas.
import 'package:intl/intl.dart';

// 2. Caminho do import corrigido para ser absoluto.
import 'package:habit_tracker/models/habit.dart';

class HabitTile extends StatelessWidget {
  final Habit habit;
  // 3. Tipos de função específicos e mais seguros.
  final ValueChanged<bool?>? onChanged;
  final VoidCallback onDelete;

  const HabitTile({
    super.key,
    required this.habit,
    required this.onChanged,
    required this.onDelete,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 2.0, // Adiciona uma leve sombra para destaque.
      margin: const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
      child: ListTile(
        contentPadding:
            const EdgeInsets.symmetric(horizontal: 10.0, vertical: 5.0),
        leading: Checkbox(
          value: habit.isCompleted,
          // 4. Passando a função diretamente. Mais limpo e eficiente.
          onChanged: onChanged,
        ),
        title: Text(
          habit.name,
          style: TextStyle(
            fontSize: 18,
            // 5. Estilo de texto mais explícito e limpo.
            decoration: habit.isCompleted
                ? TextDecoration.lineThrough
                : TextDecoration.none,
            color: habit.isCompleted ? Colors.grey : Colors.black87,
          ),
        ),
        subtitle: Text(
          // 6. Usando o pacote 'intl' para formatar a data de forma segura.
          'Criado em: ${DateFormat('dd/MM/yyyy').format(habit.createdDate)}',
          style: const TextStyle(fontSize: 12),
        ),
        trailing: IconButton(
          icon: const Icon(Icons.delete, color: Colors.redAccent),
          // 7. Passando a função diretamente.
          onPressed: onDelete,
        ),
      ),
    );
  }
}
