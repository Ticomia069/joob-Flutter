// ignore_for_file: library_private_types_in_public_api
import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:habit_tracker/services/habit_repository.dart';
import 'package:habit_tracker/services/data_service.dart';
import '../../models/habit.dart';
import 'package:habit_tracker/services/database_service.dart';

class StatisticsScreen extends StatefulWidget {
  const StatisticsScreen({super.key});

  @override
  _StatisticsScreenState createState() => _StatisticsScreenState();
}

class _StatisticsScreenState extends State<StatisticsScreen> {
  late Future<List<Habit>> _habitsFuture;

  @override
  void initState() {
    super.initState();
    _habitsFuture = _loadHabits();
  }

  /// Carrega todos os hábitos do repositório.
  Future<List<Habit>> _loadHabits() async {
    // Acede à conexão do banco de dados através do serviço.
    final database = await DatabaseService.instance.database;
    // Cria o repositório com a conexão.
    final habitRepository = HabitRepository(db: database);
    // Busca todos os hábitos usando o novo método do repositório.
    return habitRepository.getAllHabits();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Estatísticas Gerais')),
      body: FutureBuilder<List<Habit>>(
        future: _habitsFuture,
        builder: (context, snapshot) {
          // Enquanto os dados estão a carregar, mostra um indicador de progresso.
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          // Se ocorrer um erro.
          if (snapshot.hasError) {
            return Center(
                child: Text('Erro ao carregar dados: ${snapshot.error}'));
          }
          // Se não houver dados ou a lista estiver vazia.
          if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return const Center(
                child:
                    Text('Nenhum hábito registado para exibir estatísticas.'));
          }

          // Se os dados foram carregados com sucesso.
          final habits = snapshot.data!;
          final totalCount = habits.length;
          final completedCount = habits.where((h) => h.isCompleted).length;

          return _buildStatsUI(totalCount, completedCount);
        },
      ),
    );
  }

  /// Constrói a interface de utilizador das estatísticas.
  Widget _buildStatsUI(int totalCount, int completedCount) {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        children: [
          Row(
            children: [
              Expanded(
                child: _buildStatsCard(
                  'Total de Hábitos',
                  totalCount.toString(),
                  Colors.blue,
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: _buildStatsCard(
                  'Concluídos',
                  '$completedCount/$totalCount',
                  Colors.green,
                ),
              ),
            ],
          ),
          const SizedBox(height: 20),
          Expanded(
            child: PieChart(
              PieChartData(
                sections: _generateChartData(totalCount, completedCount),
                centerSpaceRadius: 60,
                sectionsSpace: 2,
              ),
            ),
          ),
        ],
      ),
    );
  }

  /// Gera os dados para o gráfico de pizza.
  List<PieChartSectionData> _generateChartData(
      int totalCount, int completedCount) {
    final pendingCount = totalCount - completedCount;

    return [
      PieChartSectionData(
        color: Colors.green,
        value: completedCount.toDouble(),
        title: '${(completedCount / totalCount * 100).toStringAsFixed(0)}%',
        radius: 50,
        titleStyle: const TextStyle(
            fontSize: 16, fontWeight: FontWeight.bold, color: Colors.white),
      ),
      PieChartSectionData(
        color: Colors.red,
        value: pendingCount.toDouble(),
        title: '${(pendingCount / totalCount * 100).toStringAsFixed(0)}%',
        radius: 50,
        titleStyle: const TextStyle(
            fontSize: 16, fontWeight: FontWeight.bold, color: Colors.white),
      ),
    ];
  }

  /// Widget para exibir um cartão de estatística.
  Widget _buildStatsCard(String title, String value, Color color) {
    return Card(
      color: color,
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            Text(
              title,
              style: const TextStyle(
                  color: Colors.white,
                  fontSize: 18,
                  fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 10),
            Text(
              value,
              style: const TextStyle(
                  color: Colors.white,
                  fontSize: 24,
                  fontWeight: FontWeight.bold),
            ),
          ],
        ),
      ),
    );
  }
}
