import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
// CAMINHOS CORRIGIDOS: Os ficheiros estão na pasta 'screens', não 'widgets/screens'.
import 'package:habit_tracker/screens/home_screen.dart';
import 'package:habit_tracker/widgets/screens/statistics_screen.dart';
import 'package:intl/date_symbol_data_local.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

Future<void> main() async {
  // O bloco try-catch irá capturar qualquer erro que ocorra durante a inicialização.
  try {
    // PASSO 1: Garantir que o Flutter está pronto.
    // É obrigatório chamar isto antes de qualquer outra coisa.
    WidgetsFlutterBinding.ensureInitialized();

    // PASSO 2: Preparar o banco de dados para DESKTOP.
    // Se a app estiver a correr no Windows, Linux ou macOS, esta configuração
    // é OBRIGATÓRIA. Sem ela, o sqflite não sabe como funcionar.
    if (!kIsWeb &&
        (Platform.isWindows || Platform.isLinux || Platform.isMacOS)) {
      sqfliteFfiInit();
      databaseFactory = databaseFactoryFfi;
    }

    // PASSO 3: Preparar a formatação de datas.
    await initializeDateFormatting('pt_BR', null);

    // PASSO 4: Iniciar a aplicação.
    runApp(const MyApp());
  } catch (e, stackTrace) {
    // PASSO DE DEBUG: Se a app falhar ao iniciar, isto irá imprimir o erro.
    // Uma tela branca é muitas vezes causada por um erro aqui.
    if (kDebugMode) {
      print('--- ERRO FATAL AO INICIAR A APP ---');
      print('ERRO: $e');
      print('RASTO DA PILHA: $stackTrace');
      print('--- FIM DO ERRO ---');
    }
  }
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Habit Tracker',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.teal),
        useMaterial3: true,
      ),
      // A rota inicial da aplicação.
      initialRoute: '/',
      // Definir as rotas nomeadas para uma navegação limpa.
      routes: {
        '/': (context) => const HomeScreen(),
        '/stats': (context) => const StatisticsScreen(),
      },
    );
  }
}
