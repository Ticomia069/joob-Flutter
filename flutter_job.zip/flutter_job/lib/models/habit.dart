class Habit {
  int? id;
  final String name;
  final DateTime createdDate;
  bool isCompleted;

  Habit({
    this.id,
    required this.name,
    required this.createdDate,
    this.isCompleted = false,
  });

  /// Converte um objeto Habit em um Map para o banco de dados.
  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'name': name,
      'createdDate': createdDate.toIso8601String(),
      'isCompleted': isCompleted ? 1 : 0,
    };
  }

  /// Constrói um objeto Habit a partir de um Map vindo do banco de dados.
  factory Habit.fromMap(Map<String, dynamic> map) {
    return Habit(
      id: map['id'],
      name: map['name'],
      createdDate: DateTime.parse(map['createdDate']),
      isCompleted: map['isCompleted'] == 1,
    );
  }
}
