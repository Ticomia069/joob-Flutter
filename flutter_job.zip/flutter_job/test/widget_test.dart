import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:habit_tracker/screens/home_screen.dart'; // Corrigido: Apenas uma importação correta

void main() {
  testWidgets(
      'HomeScreen exibe a mensagem inicial e navega para adicionar hábito',
      (WidgetTester tester) async {
    // Arrange: Constrói a tela principal dentro de um MaterialApp para dar o contexto necessário.
    await tester.pumpWidget(const MaterialApp(
      home: HomeScreen(),
    ));

    // Espera o FutureBuilder inicial do banco de dados resolver.
    await tester.pumpAndSettle();

    // Assert: Verifica se a mensagem para lista vazia (para o dia atual) é exibida.
    // Corrigido: O texto agora corresponde exatamente ao do widget.
    expect(
        find.text('Nenhum hábito para este dia.\nClique no + para adicionar.'),
        findsOneWidget);

    // Act: Simula o toque no botão de adicionar.
    await tester.tap(find.byIcon(Icons.add));

    // Espera a animação de transição da tela terminar.
    await tester.pumpAndSettle();

    // Assert: Verifica se a tela de adicionar hábito foi aberta (procurando pelo título dela).
    expect(find.text('Adicionar Novo Hábito'), findsOneWidget);
  });
}
